package com.gameassist

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView

    // Permission launchers
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkAndStart()
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            launchGameAssistService(result.data!!)
        } else {
            tvStatus.text = "Status: Screen capture denied"
            Toast.makeText(this, "Screen capture permission required!", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        tvStatus = findViewById(R.id.tvStatus)

        btnStart.setOnClickListener {
            checkAndStart()
        }

        btnStop.setOnClickListener {
            stopGameAssist()
        }
    }

    override fun onResume() {
        super.onResume()
        updateUIState()
    }

    /**
     * Check all permissions in order and start when all granted.
     */
    private fun checkAndStart() {
        // Step 1: Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            tvStatus.text = "Status: Need Overlay Permission"
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
            Toast.makeText(this, "Enable overlay permission", Toast.LENGTH_SHORT).show()
            return
        }

        // Step 2: Check accessibility service
        if (!isAccessibilityServiceEnabled()) {
            tvStatus.text = "Status: Enable Accessibility Service"
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Enable GameAssist in Accessibility Settings", Toast.LENGTH_LONG).show()
            return
        }

        // Step 3: Request screen capture
        tvStatus.text = "Status: Requesting Screen Capture..."
        requestScreenCapture()
    }

    /**
     * Check if our Accessibility Service is enabled.
     */
    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceName = "$packageName/.GameAssistService"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(serviceName)
    }

    /**
     * Request MediaProjection screen capture permission.
     */
    private fun requestScreenCapture() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as android.media.projection.MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    /**
     * Launch the GameAssist foreground service with screen capture data.
     */
    private fun launchGameAssistService(data: Intent) {
        val serviceIntent = Intent(this, GameAssistService::class.java).apply {
            action = "ACTION_START"
            putExtra("screenCaptureData", data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        tvStatus.text = "Status: GameAssist is RUNNING"
        btnStart.visibility = Button.GONE
        btnStop.visibility = Button.VISIBLE
        Toast.makeText(this, "GameAssist Started! Open your game.", Toast.LENGTH_SHORT).show()
    }

    /**
     * Stop GameAssist service.
     */
    private fun stopGameAssist() {
        val serviceIntent = Intent(this, GameAssistService::class.java).apply {
            action = "ACTION_STOP"
        }
        stopService(serviceIntent)

        tvStatus.text = "Status: Stopped"
        btnStart.visibility = Button.VISIBLE
        btnStop.visibility = Button.GONE
        Toast.makeText(this, "GameAssist Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun updateUIState() {
        val isServiceRunning = isAccessibilityServiceEnabled()
        btnStop.visibility = if (isServiceRunning) Button.VISIBLE else Button.GONE
    }
}
