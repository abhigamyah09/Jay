package com.gameassist

import android.util.Log
import com.gameassist.models.Trajectory
import kotlin.math.abs

/**
 * Predicts UFO/satellite landing positions using velocity vector analysis.
 *
 * Solves Challenge 2: UFO diagonal trajectory prediction.
 * Uses frame-to-frame position data to calculate velocity vectors (vx, vy)
 * and extrapolates the linear trajectory to predict where the object
 * will be when it reaches the player's Y level.
 *
 * Formula: y = currentY + vy * timeToReach
 * Prediction: At y = playerY, what is x?
 */
class TrajectoryPredictor(
    private val screenWidth: Int,
    private val screenHeight: Int
) {

    companion object {
        private const val TAG = "TrajectoryPredictor"
        private const val MIN_VELOCITY_FRAMES = 3     // Need 3+ frames for reliable velocity
        private const val PLAYER_Y_RATIO = 0.82f      // Player is at ~82% screen height
        private const val THREAT_SPEED_THRESHOLD = 0.5f  // Min vy to be considered falling
    }

    // Player's Y position on screen (fixed - player only moves on X)
    private val playerY: Int = (screenHeight * PLAYER_Y_RATIO).toInt()

    // Player width for "will hit" calculation
    private const val PLAYER_HALF_WIDTH = 40  // Approximate half-width of player character

    // Player's center X (updated by caller for accurate hit check)
    var playerCenterX: Int = screenWidth / 2

    /**
     * Calculate trajectory for a tracked UFO.
     * Uses position history from ObjectTracker.FramePosition.
     *
     * @return Trajectory with predicted landing X and confidence
     */
    fun predictTrajectory(positions: List<ObjectTracker.FramePosition>): Trajectory? {
        if (positions.size < MIN_VELOCITY_FRAMES) {
            Log.d(TAG, "Not enough frames (${positions.size}) for prediction, need $MIN_VELOCITY_FRAMES")
            return null
        }

        // Take last N positions for velocity calculation
        val recentPositions = positions.takeLast(MIN_VELOCITY_FRAMES)
        val first = recentPositions.first()
        val last = recentPositions.last()

        // Calculate velocity vector (average per frame)
        val frameDelta = (last.frameNumber - first.frameNumber).toFloat()
        if (frameDelta == 0f) return null

        val vx = (last.centerX - first.centerX) / frameDelta
        val vy = (last.centerY - first.centerY) / frameDelta

        // If object is barely moving vertically, it's not falling toward player
        if (vy < THREAT_SPEED_THRESHOLD) {
            Log.d(TAG, "Object not falling toward player (vy=$vy)")
            return null
        }

        if (vy <= 0) return null  // Moving upward, not a threat

        val currentY = last.centerY.toFloat()
        val currentX = last.centerX.toFloat()

        // Linear extrapolation: predict X at player Y level
        // timeToReachPlayer = (playerY - currentY) / vy
        val timeToReachPlayer = (playerY - currentY) / vy

        // If already past player level, no prediction needed
        if (timeToReachPlayer < 0) {
            Log.d(TAG, "Object already past player level")
            return null
        }

        // Predict X at player Y
        val predictedX = currentX + vx * timeToReachPlayer

        // Clamp to screen bounds
        val clampedX = predictedX.coerceIn(0f, screenWidth.toFloat()).toInt()

        // Will it hit the player area? (Check against PLAYER's X, not UFO's X)
        val willHitPlayer = abs(clampedX - playerCenterX) < PLAYER_HALF_WIDTH * 2

        // Confidence based on:
        // 1. Number of tracking frames (more = better)
        // 2. Consistency of velocity (less variance = better)
        val frameConfidence = (recentPositions.size.toFloat() / MIN_VELOCITY_FRAMES).coerceIn(0.3f, 1.0f)

        // Check velocity consistency across frames
        var consistentFrames = 0
        for (i in 1 until recentPositions.size) {
            val frameDx = (recentPositions[i].centerX - recentPositions[i - 1].centerX).toFloat()
            val frameDy = (recentPositions[i].centerY - recentPositions[i - 1].centerY).toFloat()
            val dxDiff = abs(frameDx - vx)
            val dyDiff = abs(frameDy - vy)
            if (dxDiff < 5f && dyDiff < 5f) consistentFrames++
        }
        val consistencyConfidence = if (recentPositions.size > 1) {
            consistentFrames.toFloat() / (recentPositions.size - 1)
        } else 0.5f

        val totalConfidence = (frameConfidence * 0.4f + consistencyConfidence * 0.6f)

        val trajectory = Trajectory(
            objectId = 0, // Will be set by caller
            velocityX = vx,
            velocityY = vy,
            predictedLandingX = clampedX,
            confidence = totalConfidence,
            willHitPlayer = willHitPlayer
        )

        Log.d(TAG, "Trajectory: vx=${"%.1f".format(vx)}, vy=${"%.1f".format(vy)}, " +
                "predictX=$clampedX, conf=${"%.2f".format(totalConfidence)}, hit=$willHitPlayer")

        return trajectory
    }

    /**
     * Predict meteor landing X (meteors fall mostly straight down).
     * Uses average X from recent frames as prediction.
     */
    fun predictMeteorLanding(positions: List<ObjectTracker.FramePosition>): Int? {
        if (positions.isEmpty()) return null

        if (positions.size >= 2) {
            val recent = positions.takeLast(3)
            val avgX = recent.map { it.centerX.toFloat() }.average()
            return avgX.toInt()
        }

        return positions.last().centerX
    }

    /**
     * Calculate time until a meteor reaches player Y level (in milliseconds).
     */
    fun getTimeToImpact(currentY: Int, velocityY: Float, fps: Float): Long {
        if (velocityY <= 0) return Long.MAX_VALUE
        val framesNeeded = (playerY - currentY) / velocityY
        return (framesNeeded / fps * 1000).toLong()
    }
}
